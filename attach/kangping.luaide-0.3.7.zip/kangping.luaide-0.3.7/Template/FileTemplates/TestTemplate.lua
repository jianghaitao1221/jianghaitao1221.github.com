--
--版权所有:{company}
-- Author:{author}
-- Date: {time}
--
local {moduleName} = class("{moduleName}")
function {moduleName}:ctor()
    
end
--desc:
--Author:{author}
--date:{time}
function  {moduleName}:buttonClick(sender)
    
end
function  {moduleName}:test1()
   
end
return  {moduleName}