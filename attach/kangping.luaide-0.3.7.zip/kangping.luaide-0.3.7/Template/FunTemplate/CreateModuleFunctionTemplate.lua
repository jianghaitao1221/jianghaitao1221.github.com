--=======================================
--@desc:
--time:{time}
{paramdesc}
--return 
--=======================================
function {moduleName}:{functionName}({param})
	
end